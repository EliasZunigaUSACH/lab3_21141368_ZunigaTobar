package org.example;

import java.util.List;

public interface i_option_21141368_ZunigaTobar {
    public int getOptionId();
    public String getMessage();
    public int getChatbotCodeLink();
    public int getInitialFlowCodeLink();
    public List<String> getKeywords();
}
