package org.example;

public interface i_user_21141368_ZunigaTobar {
    public String getUserName();
    public int getID();
    public boolean isAdmin();
}
