package org.example;

import java.util.List;

public interface i_flow_21141368_ZunigaTobar {
    public void flowAddOption(option_21141368_ZunigaTobar option);
    public int getFlowId();
    public String getNameMsg();
    public List<option_21141368_ZunigaTobar> getOptions();
    public void setOptions(List<option_21141368_ZunigaTobar> options);
    public List<Integer> getOptionsIds(List<option_21141368_ZunigaTobar> options);
}
